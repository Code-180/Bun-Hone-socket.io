import { z } from 'zod';
import { Hono } from 'hono';
import { join } from "path";
import { readFileSync } from "fs";
import { createServer } from "http";
import { Server } from "socket.io";
import { zValidator } from '@hono/zod-validator';
import { default as mongoose } from "mongoose";
//+++++++++++++++++++++++++++++++++++++++++++++
import user from './userService';
//+++++++++++++++++++++++++++++++++++++++++++++
const app = new Hono()
//+++++++++++++++++++++++++++++++++++++++++++++
// MongoDB Connection START
//+++++++++++++++++++++++++++++++++++++++++++++
const mongosCon: any = process.env.DB_CONNECTION_STRING;
//+++++++++++++++++++++++++++++++++++++++++++++
mongoose.connect(mongosCon)
    .then(() => {
        console.log("Database Connection Successfull!")
    })
    .catch((e) => {
        console.log(e);
        console.log("Database Connection Failed!")
    });
const clients = {};
//+++++++++++++++++++++++++++++++++++++++++++++
// Create an HTTP server
//+++++++++++++++++++++++++++++++++++++++++++++
let httpServer = createServer(app.fetch);
//+++++++++++++++++++++++++++++++++++++++++++++
// Create a Socket.IO server
//+++++++++++++++++++++++++++++++++++++++++++++
const io = new Server(httpServer);
//+++++++++++++++++++++++++++++++++++++++++++++
// setInterval(() => {
//     console.log(io.engine.readyState)
// }, 10);
io.on("connection", (socket) => {
    //+++++++++++++++++++++++++++++++++++++++++++++
    //Store the socket reference
    //+++++++++++++++++++++++++++++++++++++++++++++
    socket.on("message", (data) => {
        //+++++++++++++++++++++++++++++++++++++++++++++
        let socketIDMain = socket.id;
        //+++++++++++++++++++++++++++++++++++++++++++++
        console.log(socketIDMain);
        //+++++++++++++++++++++++++++++++++++++++++++++
        console.log("A User Connected", socketIDMain);
        //+++++++++++++++++++++++++++++++++++++++++++++
        clients[socketIDMain] = socket;
        //+++++++++++++++++++++++++++++++++++++++++++++
        console.log("Message received: " + data.m);
        //+++++++++++++++++++++++++++++++++++++++++++++
        io.emit("message_" + data.i, 'Server Session ID = ' + socketIDMain + '- ID = ' + data.i);
    });
    //+++++++++++++++++++++++++++++++++++++++++++++
    socket.on("disconnect", () => {
        console.log("User disconnected");
    });
});
//+++++++++++++++++++++++++++++++++++++++++++++
app.get("/", (c) => {
    //+++++++++++++++++++++++++++++++++++++++++++
    // Define the path to your HTML file
    //+++++++++++++++++++++++++++++++++++++++++++
    const htmlFilePath = join(process.cwd(), "src/index.html");
    const htmlContent = readFileSync(htmlFilePath, "utf-8");
    return new Response(htmlContent, {
        headers: {
            "Content-Type": "text/html",
        },
    });
});
//+++++++++++++++++++++++++++++++++++++++++++
const schemaDelete = z.object({
    ID: z.string(),
    msg: z.string(),
    socketId: z.string(),
})
//+++++++++++++++++++++++++++++++++++++++++++
app.post('/sendMeassage', zValidator('json', schemaDelete, async (result, c) => {
    let resData: any = {
        status: false,
        r: {},
        message: ''
    }
    if (!result.success) {
        resData.status = false;
        resData.message = result.error;
        return c.json(resData, 200)
    } else {
        try {
            //+++++++++++++++++++++++++++++++++++++++++
            const body = await c.req.json();
            //+++++++++++++++++++++++++++++++++++++++++
            if (clients[body.socketId]) {
                clients[body.socketId].emit('message_' + body.ID, body.msg); // Send the message to the specific socket
                return c.json({ success: true, message: 'Message sent to the socket' }, 200);
            } else {
                return c.json({ success: false, message: 'Socket not found' }, 200);
            }
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = body;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Passed";
            return c.json(resData, 200)
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = 'Error!!';
            resData.data = JSON.stringify(e);
            return c.json(resData, 200)
        }
    }
}))
//+++++++++++++++++++++++++++++++++++++++++++
// app.route('/', user);
//+++++++++++++++++++++++++++++++++++++++++++
// START THE SERVER
//+++++++++++++++++++++++++++++++++++++++++++
// Start the server on port 4000 (Chat)
//+++++++++++++++++++++++++++++++++++++++++++
httpServer.listen(4000, () => {
    console.log('Chat Server is running on http://localhost:4000');
});
//+++++++++++++++++++++++++++++++++++++++++++
// Start the server on port 3000
//+++++++++++++++++++++++++++++++++++++++++++
export default {
    port: 3000,
    fetch: app.fetch,
}